package com.example.pizza_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class AddCustomerController
{
    private static String user;
    @FXML
    private TextField firstNameField,lastNameField,addressField,phoneField,paymentTypeField;
    @FXML
    private Label addCustomerMessage, userNameLabel;



    @FXML
    public void addCustomer(ActionEvent actionEvent)
    {
        try
        {
            isEmptyField(); //Checks for any empty text fields
            CustomerDatabase customerDatabase = new CustomerDatabase(); //Accesses the customer database

            String firstName = firstNameField.getText();    //Gets customer information from the textfields
            String lastName = lastNameField.getText();
            String address = addressField.getText();
            String phone = phoneField.getText();
            String payment = paymentTypeField.getText();

            customerDatabase.add(phone,firstName,lastName,payment,address); //Adds customer to the database
            addCustomerMessage.setStyle("-fx-text-fill: #0100ff");
            addCustomerMessage.setText("Customer Successfully added to database");

            firstNameField.clear();
            lastNameField.clear();
            addressField.clear();
            phoneField.clear();
            paymentTypeField.clear();
        }
        catch(EmptyFieldException e)
        {
            addCustomerMessage.setStyle("-fx-text-fill: #ff0000");
            addCustomerMessage.setText(e.getMessage());
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    public void isEmptyField() throws EmptyFieldException
    {
        //If any of the fields are empty, it will throw an exception
        if(firstNameField.getText().isEmpty() || lastNameField.getText().isEmpty() || addressField.getText().isEmpty() ||
                phoneField.getText().isEmpty() || paymentTypeField.getText().isEmpty())
        {
            throw new EmptyFieldException("All fields must be filled out!");
        }

    }




    @FXML
    public void loggingOut(ActionEvent actionEvent) //Switches to log out screen
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("logOut.fxml"));
            Parent root = loader.load();

            LogOutController logOutController = loader.getController();
            logOutController.setFileString("addCustomerPage.fxml");
            logOutController.setUserName(user);

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
        }
        catch(IOException e)
        {
            System.out.println(e.getMessage());
        }
    }

    public void goBack(ActionEvent actionEvent) throws IOException //When back button is clicked, the current page will go to the previous page
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("customersMain.fxml"));
        Parent root = loader.load();

        CustomersMainController controller = loader.getController();
        controller.setUserNameLabel(user);

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    public void setUserNameLabel(String s)
    {
        user = s;
        userNameLabel.setText(user);
    }
}
