package com.example.pizza_system;
public class PizzaDatabase extends CsvDatabase
{

    public PizzaDatabase() throws Exception
    {
        super("PizzaDatabase.csv", 6, "PizzaID,CustomerPhoneNumber,Price,Toppings,Size,Crust\r\n");
    }

    public void add(String PizzaID, String OrderID, String Price, String Toppings, String Size, String Crust) throws Exception
    {
        //if the passed information has too many commas through an Exception
        if(Price.contains(",") || Toppings.contains(",") || Size.contains(",") || Crust.contains(","))
        {
            throw new Exception("Values cannot contain ','");
        }
        open();
        ThisDatabase += PizzaID+","+OrderID+","+Price+","+Toppings+","+Size+","+Crust+"\r";
        close();
    }

    public int getOrderID(String GivenPizzaID) throws Exception //Gets the OrderID from an individual pizza
    {
        if(indexOf(GivenPizzaID) < 0)
        {
            throw new Exception("PizzaID not found");
        }
        else
        {
            return Integer.parseInt(fieldAt(indexOf(GivenPizzaID) + 1));       //Returns the order ID of a specific pizza
        }
    }

    public float getPrice(String GivenPizzaID) throws Exception
    {
        if(indexOf(GivenPizzaID) < 0)
        {
            throw new Exception("PizzaID was not found");
        }
        return Float.parseFloat(fieldAt(indexOf(GivenPizzaID) +2));
    }

    public String getToppings(String GivenPizzaID) throws Exception
    {
        if(indexOf(GivenPizzaID) < 0)
        {
            throw new Exception("PizzaID was not found");
        }
        else
        {
            String t = fieldAt(indexOf(GivenPizzaID) + 3);      //Holds the string of toppings
            return t;
        }
    }

    public String getSize(String GivenPizzaID) throws Exception
    {
        if(indexOf(GivenPizzaID) < 0)
        {
            throw new Exception("PizzaID was not found");
        }
        else
        {
            return fieldAt(indexOf(GivenPizzaID) + 4);
        }
    }

    public String getCrust(String GivenPizzaID) throws Exception
    {
        if(indexOf(GivenPizzaID) < 0)
        {
            throw new Exception("PizzaID was not found");
        }
        else
        {
            return fieldAt(indexOf(GivenPizzaID) + 5);
        }
    }

    public void setPrice(String GivenPizzaID, String set_price) throws Exception
    {
        if(indexOf(GivenPizzaID) < 0)
        {
            throw new Exception("PizzaID was not found");
        }

        else{
            setIndex(indexOf(GivenPizzaID) + 2, set_price);
        }
    }

    public void setToppings(String GivenPizzaID, String toppings) throws Exception
    {
        if(indexOf(GivenPizzaID) < 0)
        {
            throw new Exception("PizzaID was not found");
        }

        else{
            setIndex(indexOf(GivenPizzaID) + 3, toppings);
        }
    }

    public void setSize(String GivenPizzaID, String size) throws Exception
    {
        if(indexOf(GivenPizzaID) < 0)
        {
            throw new Exception("PizzaID was not found");
        }

        else{
            setIndex(indexOf(GivenPizzaID) + 4, size);
        }
    }

    public void setCrust(String GivenPizzaID, String crust) throws Exception
    {
        if(indexOf(GivenPizzaID) < 0)
        {
            throw new Exception("PizzaID was not found");
        }

        else{
            setIndex(indexOf(GivenPizzaID) + 5, crust);
        }
    }

    //Add calculate_price_method that calculates the price by pulling prices of toppings from MenuDatabase class







}
