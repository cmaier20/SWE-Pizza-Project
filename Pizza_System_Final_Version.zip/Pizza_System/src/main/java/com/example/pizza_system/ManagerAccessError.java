package com.example.pizza_system;

public class ManagerAccessError extends Exception
{
    ManagerAccessError(String s)
    {
        super(s);
    }
}
