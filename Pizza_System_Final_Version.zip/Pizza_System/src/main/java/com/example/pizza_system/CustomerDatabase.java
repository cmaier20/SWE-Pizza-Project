package com.example.pizza_system;
public class CustomerDatabase extends CsvDatabase{
    //Constructor Method
    CustomerDatabase() throws Exception{
        super("CustomerDatabase.csv", 5, "Phone Number,First Name,Last Name,Customer Payment Type,Address \r\n");
    }

    //Setter methods


    //Adds a customer (Each field is separated)
    public void add(String PhoneNumber, String FirstName, String LastName, String PaymentType, String Address) throws Exception {
        //if the passed information has too many commas through an Exception
        if(PhoneNumber.contains(",") || FirstName.contains(",") || LastName.contains(",") || PaymentType.contains(",") || Address.contains(",")) {
            throw new Exception("None of the Fields can contain any ','");
        }
        open();
        ThisDatabase += PhoneNumber+","+FirstName+","+LastName+","+PaymentType+","+Address+"\r";
        close();
    }

    public void setFirstName(String GivenName, String GivenPhoneNumber)
    {
        setIndex(indexOf(GivenPhoneNumber)+1 ,GivenName);
    }

    public void setLastName(String GivenName, String GivenPhoneNumber)
    {
        setIndex(indexOf(GivenPhoneNumber)+2 ,GivenName);
    }

    public void setPaymentType(String GivenType, String GivenPhoneNumber)
    {
        setIndex(indexOf(GivenPhoneNumber)+3 ,GivenType);
    }

    //Sets Address of GivenPhoneNumber to GivenAddress
    public void setAddress(String GivenAddress, String GivenPhoneNumber)
    {
        setIndex(indexOf(GivenPhoneNumber)+4 ,GivenAddress);
    }


    //Getter Methods


    //getFirstName(String GivenPhoneNumber) returns FirstName of GivenPhoneNumber
    public String getFirstName(String GivenPhoneNumber) {
        if(indexOf(GivenPhoneNumber) != -1) {
            return fieldAt(indexOf(GivenPhoneNumber)+1);
        }
        else
            return null;
    }

    //getLastName(String GivenPhoneNumber) returns LastName of GivenPhoneNumber
    public String getLastName(String GivenPhoneNumber) {
        if(indexOf(GivenPhoneNumber) != -1) {
            return fieldAt(indexOf(GivenPhoneNumber)+2);
        }
        else
            return null;
    }

    //getLastName(String GivenPhoneNumber) returns PaymentType of GivenPhoneNumber
    public String getPaymentType(String GivenPhoneNumber) {
        if(indexOf(GivenPhoneNumber) != -1) {
            return fieldAt(indexOf(GivenPhoneNumber)+3);
        }
        else
            return null;
    }

    //getAddress(String GivenPhoneNumber) returns Address of GivenPhoneNumber
    public String getAddress(String GivenPhoneNumber) {
        if(indexOf(GivenPhoneNumber) != -1) {
            return fieldAt(indexOf(GivenPhoneNumber)+4);
        }
        else
            return null;
    }
}
