package com.example.pizza_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;

public class BuildPizzaController {
    @FXML
    private TextField QuantityChoice;

    private static String user;
    private String customerPhoneNumber;
    private String deliveryorPickup;
    private String pizzaID;
    private int quantity;

    @FXML
    private RadioButton size1, size2,size3,size4, crust1, crust2,crust3;

    @FXML
    private Label userNameLabel;

    private String pizzaSize = "10 in";
    private double sizePrice = 8.00;

    private String crust = "Hand Tossed";
    private double crustPrice = 8.00;

    private double total;

    private boolean hasPepperoni, hasSalami, hasBacon, hasHam, hasBeef, hasChicken,
            hasMushrooms,hasGreenPeppers, hasOnions, hasPineapple,hasBlackOlives, hasBellPeppers = false;

    private double toppingsTotal = 0.0;

    @FXML
    private TextField quantityField;

    @FXML
    public void confirmButtonClicked(ActionEvent actionEvent) throws Exception {

        String toppings = "";
        if(hasPepperoni)
        {
            toppingsTotal++;
            toppings += "Pepperoni ";
        }

        if(hasSalami)
        {
            toppingsTotal++;
            toppings += "Salami ";
        }

        if(hasBacon)
        {
            toppingsTotal++;
            toppings += "Bacon ";
        }

        if(hasHam)
        {
            toppingsTotal++;
            toppings += "Ham ";
        }

        if(hasBeef)
        {
            toppingsTotal++;
            toppings += "Beef ";
        }

        if(hasChicken)
        {
            toppingsTotal++;
            toppings += "Chicken ";
        }

        if(hasMushrooms)
        {
            toppingsTotal++;
            toppings += "Mushrooms ";
        }

        if(hasGreenPeppers)
        {
            toppingsTotal++;
            toppings += "Green Peppers ";
        }

        if(hasOnions)
        {
            toppingsTotal++;
            toppings += "Onions ";
        }

        if(hasPineapple)
        {
            toppingsTotal++;
            toppings += "Pineapple ";
        }

        if(hasBlackOlives)
        {
            toppingsTotal++;
            toppings += "Black Olives ";
        }

        if(hasBellPeppers)
        {
            toppingsTotal++;
            toppings += "Bell Peppers ";
        }

        total = (toppingsTotal + sizePrice + crustPrice);


        PizzaDatabase database = new PizzaDatabase();
        pizzaID = generateID();
        database.add(pizzaID,customerPhoneNumber,String.valueOf(total),toppings,pizzaSize,crust); // adds new pizza to database

        switchToMenuPage(actionEvent);
    }

    public void switchToMenuPage(ActionEvent actionEvent) throws Exception, IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuPage.fxml"));
        Parent root = loader.load();

        MenuPageController controller = loader.getController();
        controller.setUserNameLabel(user);
        controller.setDeliveryorPickup(deliveryorPickup);
        controller.setCustomerPhoneNumber(customerPhoneNumber);
        controller.setFullNameLabel();
        controller.setPizzaID(pizzaID);
        quantity = Integer.parseInt(quantityField.getText());
        controller.setQuantity(quantity);
        controller.setOrderTextArea();


        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void setPizzaSize1(ActionEvent actionEvent)
    {
        size1.setSelected(true);
        size2.setSelected(false);
        size3.setSelected(false);
        size4.setSelected(false);

        pizzaSize = "10 in";
        sizePrice = 8.00;
    }

    @FXML
    public void setPizzaSize2(ActionEvent actionEvent)
    {
        size1.setSelected(false);   //Buttons are turned off
        size2.setSelected(true);    //Button is turned on
        size3.setSelected(false);
        size4.setSelected(false);

        pizzaSize = "12 in";
        sizePrice = 10.00;
    }


    @FXML
    public void setPizzaSize3(ActionEvent actionEvent)
    {
        size1.setSelected(false);
        size2.setSelected(false);
        size3.setSelected(true);
        size4.setSelected(false);

        pizzaSize = "14 in";
        sizePrice = 12.00;
    }

    @FXML
    public void setPizzaSize4(ActionEvent actionEvent)
    {
        size1.setSelected(false);
        size2.setSelected(false);
        size3.setSelected(false);
        size4.setSelected(true);

        pizzaSize = "18 in";
        sizePrice = 14.00;
    }



    @FXML
    public void setCrust1(ActionEvent actionEvent)
    {
        crust1.setSelected(true);
        crust2.setSelected(false);
        crust3.setSelected(false);

        crust = "Hand Tossed";
        crustPrice = 1.00;
    }

    @FXML
    public void setCrust2(ActionEvent actionEvent)
    {
        crust1.setSelected(false);
        crust2.setSelected(true);
        crust3.setSelected(false);

        crust = "Thin";
        crustPrice = 1.10;
    }

    @FXML
    public void setCrust3(ActionEvent actionEvent)
    {
        crust1.setSelected(false);
        crust2.setSelected(false);
        crust3.setSelected(true);

        crust = "Thick";
        crustPrice = 1.15;
    }

    @FXML
    public void pepperoniChecked(ActionEvent actionEvent)
    {
        if(hasPepperoni)
        {
            hasPepperoni = false;
        }
        hasPepperoni = true;

    }

    @FXML
    public void salamiChecked(ActionEvent actionEvent)
    {
        if(hasSalami)
        {
            hasSalami = false;
        }
        hasSalami = true;
    }

    @FXML
    public void hamChecked(ActionEvent actionEvent)
    {
        if(hasHam)
        {
            hasHam = false;
        }
        hasHam = true;
    }

    @FXML
    public void baconChecked(ActionEvent actionEvent)
    {
        if(hasBacon)
        {
            hasBacon = false;
        }
        hasBacon = true;
    }

    @FXML
    public void beefChecked(ActionEvent actionEvent)
    {
        if(hasBeef)
        {
            hasBeef = false;
        }
        hasBeef = true;
    }

    @FXML
    public void chickenChecked(ActionEvent actionEvent)
    {
        if(hasChicken)
        {
            hasChicken = false;
        }
        hasChicken = true;
    }

    @FXML
    public void mushroomChecked(ActionEvent actionEvent)
    {
        if(hasMushrooms)
        {
            hasMushrooms = false;
        }
        hasMushrooms = true;
    }

    @FXML
    public void bellPeppersChecked(ActionEvent actionEvent)
    {
        if(hasBellPeppers)
        {
            hasBellPeppers = false;
        }

        hasBellPeppers = true;
    }

    @FXML
    public void greenPeppersChecked(ActionEvent actionEvent)
    {
        if(hasGreenPeppers)
        {
            hasGreenPeppers = false;
        }
        hasGreenPeppers = true;
    }

    @FXML
    public void onionsChecked(ActionEvent actionEvent)
    {
        if(hasOnions)
        {
            hasOnions = false;
        }
        hasOnions = true;
    }

    @FXML
    public void pineappleChecked(ActionEvent actionEvent)
    {
        if(hasPineapple)
        {
            hasPineapple = false;
        }
        hasPineapple= true;
    }

    @FXML
    public void blackOlivesChecked(ActionEvent actionEvent)
    {
        if(hasBlackOlives)
        {
            hasBlackOlives = false;
        }
        hasBlackOlives = true;
    }

    public void setCustomerPhoneNumber(String s )
    {
        customerPhoneNumber = s;
    }
    public void setUserNameLabel(String s)
    {
        user = s;
        userNameLabel.setText(s);
    }

    public void setDeliveryorPickup(String s)
    {
        deliveryorPickup = s;
    }



    private String generateID()
    {
        String alpha_num = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder s = new StringBuilder();
        Random rand = new Random();
        s.append("p");
        while(s.length() < 5)
        {
            int i = (int)(rand.nextFloat() * alpha_num.length());
            s.append(alpha_num.charAt(i));
        }
        String id = s.toString();
        return id;
    }


    public void loggingOut(ActionEvent actionEvent)
    {

    }
}