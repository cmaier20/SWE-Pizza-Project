package com.example.pizza_system;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class LogOutController
{
    private String fileString,custPhoneNumber;
    private static String userName;


    @FXML
    public void yesLogOut(ActionEvent actionEvent)
    {
        Platform.exit();    //Program ends
    }

    @FXML
    public void noLogOut(ActionEvent actionEvent) throws Exception
    {
        if(fileString.equals("mainPage.fxml"))
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fileString));
            Parent root = loader.load();

            MainPageController controller = loader.getController();
            controller.setUserNameLabel(userName);

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
            return;
        }
        else if(fileString.equals("customersMain.fxml"))
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fileString));
            Parent root = loader.load();

            CustomersMainController controller = loader.getController();
            controller.setUserNameLabel(userName);

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
            return;
        }
        else if(fileString.equals("addCustomerPage.fxml"))
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fileString));
            Parent root = loader.load();

            AddCustomerController controller = loader.getController();
            controller.setUserNameLabel(userName);

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
            return;
        }
        else if(fileString.equals("viewCustomersPage.fxml"))
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fileString));
            Parent root = loader.load();

            ViewCustomersController controller = loader.getController();
            controller.setUserNameLabel(userName);
            controller.getCustomerData();

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
            return;
        }


        FXMLLoader loader = new FXMLLoader(getClass().getResource(fileString));
        Parent root = loader.load();

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    public void setFileString(String s)
    {
        fileString = s;
    }
    public void setUserName(String s){userName = s;}
    public void setCustPhone(String s){custPhoneNumber = s;}
}

