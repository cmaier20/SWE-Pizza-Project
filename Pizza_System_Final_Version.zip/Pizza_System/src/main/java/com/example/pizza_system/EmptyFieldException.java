package com.example.pizza_system;

public class EmptyFieldException extends Exception
{
    EmptyFieldException(String s)
    {
        super(s);
    }
}
