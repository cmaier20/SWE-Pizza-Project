package com.example.pizza_system;

import java.io.*;
import java.util.*;

public class CsvDatabase {
    //Declare Variables

    //Call to write to csv
    protected FileWriter writer = null;
    //Call to read from csv
    protected Scanner reader = null;
    //Holds all of the information written in the csv file
    protected String ThisDatabase = "";
    //Name of csv file
    protected String FileName;
    //Number of Columns in the csv file
    protected int fields;
    //Holds the Name of the Columns Needs to end in \r
    protected String FirstRow;




    //Constructor Method
    CsvDatabase(String nFileName, int nFields, String nFirstRow) throws Exception{
        try {
            FileName = nFileName;
            fields = nFields;
            FirstRow = nFirstRow;
            //Create a reader will fail if EmployeeDatabase.csv does not exist
            reader = new Scanner(new File(FileName));
            //checks if the csv has any data if it does we copy if to ThisDatabase
            if(reader.hasNextLine()) {
                while(reader.hasNextLine()) {
                    ThisDatabase += reader.nextLine()+"\r";
                }
            }
            //If not we set ThisDatabase equal to the expected first row
            else {
                ThisDatabase = FirstRow;
            }
        }
        catch(FileNotFoundException  a) {
            //If we are down here then there is no csv file so we create it and set ThisDatabase equal to the expected first row
            new File(FileName);
            ThisDatabase = FirstRow;
        }
        catch(Exception e) {
            //If we are down here then we encountered a big error
            System.out.println("EmployeeDatabase():"+e.getMessage());
        }
    }






    //Setter Methods


    //Adds a user (fields are given in one String)
    public void add(String Information)  throws Exception {
        //if the passed information has too many commas through an Exception
        if(!rightAmountOfCommas(Information)) {
            throw new Exception("Username and Password can not contain any ','");
        }
        open();
        String Temp = Information.substring(0, Information.indexOf(','));
        Information = Information.substring(Information.indexOf(','));
        Information = Temp + Information.replaceAll(" ", "");
        Information = Information.replaceAll("\r", "");
        Information = Information.replaceAll("\n", "");
        ThisDatabase += Information+"\r";
        close();
    }


    //Removes a Entry By GivenKey (Name of FirstRow ex UserName)
    public void remove(String GivenKey) {
        if(indexOf(GivenKey) != -1) {
            open();
            String BeforeGivenKey = ThisDatabase.substring(0, ThisDatabase.indexOf(GivenKey)-1);
            String AfterGivenKey = "";
            int i = indexOf(GivenKey)+fields;
            while(fieldAt(i) != null) {
                if(i%fields == 0) {
                    AfterGivenKey +="\r";
                }
                AfterGivenKey += fieldAt(i)+",";
                i++;
            }
            if(AfterGivenKey != "") {
                AfterGivenKey = AfterGivenKey.substring(0, AfterGivenKey.length()-1);
                ThisDatabase = BeforeGivenKey + AfterGivenKey;
            } else {
                ThisDatabase = BeforeGivenKey;
            }
            close();
            System.out.println(GivenKey+" has been removed");
        } else
            System.out.println(GivenKey+" is not in the Database");
    }



    //Getter Methods


    //fieldAt(int index) returns the field at index (does not include the first row)
    protected String fieldAt(int index) {
        //Creates String Unprocessed which removes the first row and last character of ThisDatabase
        String Unprocessed = ThisDatabase.substring(ThisDatabase.indexOf('\r')+1, ThisDatabase.length()-1);
        //Replaces all of the '/r' in Unprocessed with ' '
        Unprocessed = Unprocessed.replaceAll("\r", ",");
        //Keeps track of the current index we are testing
        int curIndex = 0;
        //Repeats until we arrived at our index or ran out of indexes to check
        while(curIndex < index && Unprocessed.contains(",")){
            //removes one field from Unprocessed
            Unprocessed = Unprocessed.substring(Unprocessed.indexOf(',')+1);
            //Increments curIndex
            curIndex++;
        }
        //if Unprocessed still contains ',' return a substring of Unprocessed up until the first ','
        if(curIndex == index && Unprocessed.contains(","))
            return Unprocessed.substring(0, Unprocessed.indexOf(','));
            //if there are no other ',' just return Unprocessed
        else if (curIndex == index)
            return Unprocessed;
            //ThisDatabase does not have the index requested so returns null
        else
            return null;
    }


    //indexOf(String GivenString) returns the index of the given String or -1 if not found
    //return first instance so only works on keys
    protected int indexOf(String GivenString) {
        //Search through the database until it either finds the GivenString or check every index (fieldAt return null)
        for(int i = 0; fieldAt(i) != null; i++) {
            if(fieldAt(i).equals(GivenString))
                return i;
        }
        //return a -1 if the GivenString is not found
        return -1;
    }


    //toString() returns ThisDatabase
    @Override
    public String toString() {
        return ThisDatabase;
    }





    //Other Methods


    //Open Method must run before making changes
    public void open() {
        try{
            reader = new Scanner(new File(FileName));
        }
        catch(FileNotFoundException  a) {
            new File(FileName);
        }
        catch(Exception e) {
            System.out.println("open():"+e.getMessage());
        }
    }


    //Close Methods run after making changes to save them
    public void close(){
        try {
            writer = new FileWriter(FileName);
            writer.append(ThisDatabase);
            writer.close();
            if(reader != null)
                reader.close();
        }
        catch(FileNotFoundException  a) {
            new File(FileName);
        }
        catch(Exception e) {
            System.out.println("close():"+e.getMessage());
        }
    }


    //rightAmountOfCommas(String GivenString) returns true if the GivenString contains less then fields commas
    //If fields contain commas it messes up the formating of the csv file
    public boolean rightAmountOfCommas(String GivenString) {
        int result = 0;
        for (int i = 0; i < GivenString.length(); i++) {
            if(GivenString.charAt(i) == ',')
                result ++;
        }
        if(result < fields ) {
            return true;
        }else
            return false;
    }


    //Sets GivenIndex equal to GivenString
    public void setIndex(int givenIndex, String GivenString)
    {
        String TempTop = "";
        String TempBottom = ThisDatabase.replaceAll("\r", ",");
        //Keeps track of the current index we are testing
        int curIndex = 0;
        //Repeats until we arrived at our index or ran out of indexes to check
        while(curIndex < givenIndex && TempBottom.contains(",")){
            TempTop = TempBottom.substring(0, TempBottom.indexOf(',')+1);
            TempBottom = TempBottom.substring(TempBottom.indexOf(',')+1);
            //Increments curIndex
            curIndex++;
        }
        TempBottom = TempBottom.substring(TempBottom.indexOf(',')+1);
        //ThisDatabase = TempTop + TempBottom;
        System.out.println(TempTop + GivenString+ "," +TempBottom);
    }


}

