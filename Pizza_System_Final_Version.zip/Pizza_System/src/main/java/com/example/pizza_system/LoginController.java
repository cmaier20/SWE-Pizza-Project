package com.example.pizza_system;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.stage.Stage;

public class LoginController
{
    @FXML
    private Label incorrectText;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    public void tryLogin(ActionEvent actionEvent)
    {
        try
        {
            EmployeeDatabase employeeDatabase = new EmployeeDatabase(); //Uses employeedatabase
            String user = username.getText();   //Gets input from username textfield
            String pass = password.getText();   //Gets input from password passwordfield

            if(employeeDatabase.checkPassword(user,pass))   //If username and password exist in the database, go to main page
            {

                FXMLLoader loader = new FXMLLoader(getClass().getResource("mainPage.fxml"));
                Parent root = loader.load();

                MainPageController mainPageController = loader.getController(); //Loads controller
                mainPageController.setUserNameLabel(user);                     //Sets the username on next page to equal the username from textfield

                Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
                Scene scene = new Scene(root,650,500);
                stage.setScene(scene);
                stage.show();
            }

        }
        catch(Exception e)
        {
            incorrectText.setText("Incorrect Username or Password! Please try again");  //if username or password isn't found
        }
    }









}