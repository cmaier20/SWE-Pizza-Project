package com.example.pizza_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.IOException;


public class MenuPageController {
    private static String textAreaText ="";
    private static String user;
    private String customerPhoneNumber;
    private String deliveryorPickup;
    private String pizzaID;
    private int quantity;
    private double totalCost;

    @FXML
    private TextArea orderTextArea;

    @FXML
    private Label userNameLabel, fullNameLabel,orderTypeLabel;


    @FXML
    public void BuildYourPizza(ActionEvent actionEvent) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("BuildPizza.fxml"));
        Parent root = loader.load();

        BuildPizzaController controller = loader.getController();
        controller.setUserNameLabel(user);
        controller.setDeliveryorPickup(deliveryorPickup);
        controller.setCustomerPhoneNumber(customerPhoneNumber);

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void Beverages(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Beverage.fxml"));
        Parent root = loader.load();

        BeverageController controller = loader.getController();
        controller.setUserNameLabel(user);
        controller.setDeliveryorPickup(deliveryorPickup);
        controller.setCustomerPhoneNumber(customerPhoneNumber);

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void ConfirmOrder(ActionEvent actionEvent) throws Exception {
        CustomerDatabase db = new CustomerDatabase();
        String paymentType = db.getPaymentType(customerPhoneNumber);

        if(paymentType.equalsIgnoreCase("Credit Card"))
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ReceiptPage.fxml"));
            Parent root = loader.load();

            ReceiptPageController controller = loader.getController();
            controller.setUserNameLabel(user);
            controller.setDeliveryorPickup(deliveryorPickup);
            controller.setCustomerPhoneNumber(customerPhoneNumber);
            controller.setAddressLabel();
            controller.setPaymentTypeLabel();
            controller.setFullNameLabel();
            controller.setTextAreaReceipt(textAreaText);
            controller.setSubTotal(totalCost);

            //settextareatext, totalcost

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainPage.fxml"));
            Parent root = loader.load();

            MainPageController controller = loader.getController();
            controller.setUserNameLabel(user);

            FXMLLoader loader_menu = new FXMLLoader(getClass().getResource("MenuPage.fxml"));
            Parent root_menu = loader_menu.load();
            MenuPageController controller_menu = loader_menu.getController();
            controller_menu.resetText();

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
        }

    }

    @FXML
    public void loggingOut(ActionEvent actionEvent)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("logOut.fxml"));
            Parent root = loader.load();

            LogOutController logOutController = loader.getController();
            logOutController.setFileString("MenuPage.fxml");
            logOutController.setUserName(user);

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
        }
        catch(IOException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void goBack(ActionEvent actionEvent) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ordersMainPage.fxml"));
        Parent root = loader.load();

        OrdersMainController controller = loader.getController();
        controller.setUserNameLabel(user);

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    public void setUserNameLabel(String s)
    {
        user = s;
        userNameLabel.setText(s);
    }

    public void setCustomerPhoneNumber(String s )
    {
        customerPhoneNumber = s;
    }

    public void setDeliveryorPickup(String s)
    {
        deliveryorPickup = s;
        orderTypeLabel.setText(s);
    }

    public void setFullNameLabel() throws Exception
    {
        CustomerDatabase db = new CustomerDatabase();

        String first = db.getFirstName(customerPhoneNumber);
        String last = db.getLastName(customerPhoneNumber);

        fullNameLabel.setText(first+", "+last);
    }

    public void setPizzaID(String s)
    {
        pizzaID = s;
    }

    public void setQuantity(int i)
    {
        quantity = i;
    }




    public void setOrderTextArea() throws Exception {
        PizzaDatabase db = new PizzaDatabase();

        if(pizzaID.charAt(0) == 'p')
        {
            totalCost += db.getPrice(pizzaID);
            textAreaText += "Quantity: "+quantity+"\t$"+db.getPrice(pizzaID)+"\tSize: " +
                    ""+db.getSize(pizzaID)+" Crust: "+db.getCrust(pizzaID)+"\n\t\t"+db.getToppings(pizzaID)+"\n\n";
        }

        if(pizzaID.charAt(0) == 'b')
        {
            totalCost += db.getPrice(pizzaID);
            textAreaText += "\t\t $: "+db.getPrice(pizzaID)+"\tQuantity: " +db.getToppings(pizzaID)+"\n\n";

        }




        //"Quantity: "+quantity+"\t$"+db.getPrice(pizzaID)+"\tSize: "+db.getSize(pizzaID)+" Crust: "+db.getCrust(pizzaID)+"\n\t\t"+db.getToppings(pizzaID)
        //Quantity, Price, size, crust,
        orderTextArea.setText(textAreaText);
    }

    public void resetText()
    {
        textAreaText ="";
    }





}