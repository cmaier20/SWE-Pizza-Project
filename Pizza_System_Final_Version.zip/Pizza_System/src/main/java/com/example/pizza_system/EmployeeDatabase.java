package com.example.pizza_system;
public class EmployeeDatabase extends CsvDatabase{
    //Constructor Method
    EmployeeDatabase() throws Exception{
        super("EmployeeDatabase.csv", 3, "Username,Password,Managerial Access\r\n");
    }





    //Setter Methods


    //Adds a user (Each field is separated)
    public void add(String Username, String Password, String ManAcess) throws Exception {
        //if the passed information has too many commas through an Exception
        if(Username.contains(",") || Password.contains(",")) {
            throw new Exception("Username and Password can not contain any ','");
        }
        open();
        ThisDatabase += Username+","+Password+","+ManAcess.toLowerCase()+"\r";
        close();
    }





    //Getter Methods


    //getPassword(String GivenUserName) should return the password
    private String getPassword(String GivenUsername) {
        //if the database contains the GivenUserName return it
        if(indexOf(GivenUsername) != -1) {
            return fieldAt(indexOf(GivenUsername)+1);
        }
        //Otherwise return null
        else
            return null;
    }


    //checkPassword(String GivenUsername, String GivenPassword) Checks to see if handed a correct Username Password combo returns true if have
    public boolean checkPassword(String GivenUsername, String GivenPassword) {
        if(getPassword(GivenUsername).equals(GivenPassword)) {
            return true;
        } else
            return false;
    }

    //checkManagerialAccess(String GivenUsername) returns the value of Managerial Access for that User
    public boolean checkManagerialAccess(String GivenUsername) {
        if(fieldAt(indexOf(GivenUsername)+2).equals("true")) {
            return true;
        }else
            return false;
    }

}
