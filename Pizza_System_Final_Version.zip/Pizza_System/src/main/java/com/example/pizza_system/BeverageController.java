package com.example.pizza_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Random;

public class BeverageController {


    private static String user;
    private String customerPhoneNumber;
    private String deliveryorPickup;

    @FXML
    private Label userNameLabel;




    @FXML
    private TextField cc1,cc2,cc3,md1,md2,md3,fo1,fo2,fo3,dr1,dr2,dr3,sp1,sp2,sp3;  //Beverage fx:ids
    private int cc1Quantity,cc2Quantity, cc3Quantity, md1Quantity, md2Quantity,md3Quantity, fo1Quantity
            ,fo2Quantity, fo3Quantity, dr1Quantity, dr2Quantity, dr3Quantity, sp1Quantity, sp2Quantity, sp3Quantity =0;
    private double priceSmall = 1.00;
    private double priceMedium = 1.50;
    private double priceLarge = 2.00;
    private double totalPrice =0.0;

    private String beverageID;


    @FXML
    public void getSodaQuantities(ActionEvent actionEvent)
    {

            cc1Quantity = Integer.parseInt(cc1.getText());
            cc2Quantity = Integer.parseInt(cc2.getText());
            cc3Quantity = Integer.parseInt(cc3.getText());
            md1Quantity = Integer.parseInt(md1.getText());
            md2Quantity = Integer.parseInt(md2.getText());
            md3Quantity = Integer.parseInt(md3.getText());
            fo1Quantity = Integer.parseInt(fo1.getText());
            fo2Quantity = Integer.parseInt(fo2.getText());
            fo3Quantity = Integer.parseInt(fo3.getText());
            dr1Quantity = Integer.parseInt(dr1.getText());
            dr2Quantity = Integer.parseInt(dr2.getText());
            dr3Quantity = Integer.parseInt(dr3.getText());
            sp1Quantity = Integer.parseInt(sp1.getText());
            sp2Quantity = Integer.parseInt(sp2.getText());
            sp3Quantity = Integer.parseInt(sp3.getText());

    }

    @FXML
    public void confirmButtonClicked(ActionEvent actionEvent) throws Exception
    {
        PizzaDatabase db = new PizzaDatabase();
        cc1Quantity = Integer.parseInt(cc1.getText());
        cc2Quantity = Integer.parseInt(cc2.getText());
        cc3Quantity = Integer.parseInt(cc3.getText());
        md1Quantity = Integer.parseInt(md1.getText());
        md2Quantity = Integer.parseInt(md2.getText());
        md3Quantity = Integer.parseInt(md3.getText());
        fo1Quantity = Integer.parseInt(fo1.getText());
        fo2Quantity = Integer.parseInt(fo2.getText());
        fo3Quantity = Integer.parseInt(fo3.getText());
        dr1Quantity = Integer.parseInt(dr1.getText());
        dr2Quantity = Integer.parseInt(dr2.getText());
        dr3Quantity = Integer.parseInt(dr3.getText());
        sp1Quantity = Integer.parseInt(sp1.getText());
        sp2Quantity = Integer.parseInt(sp2.getText());
        sp3Quantity = Integer.parseInt(sp3.getText());

        totalPrice = priceSmall * (cc1Quantity + md1Quantity + fo1Quantity + dr1Quantity + sp1Quantity);
        totalPrice += priceMedium * (cc2Quantity + md2Quantity + fo2Quantity + dr2Quantity + sp2Quantity);
        totalPrice += priceLarge * (cc3Quantity + md3Quantity + fo3Quantity + dr3Quantity + sp3Quantity);

        String quantity = "";
        if(Integer.parseInt(cc1.getText()) != 0)
        {
            quantity += (cc1.getText() +" Small Coca Cola ");
        }

        if(Integer.parseInt(cc2.getText()) != 0)
        {
            quantity += (cc2.getText() +" Medium Coca Cola ");
        }

        if(Integer.parseInt(cc3.getText()) != 0)
        {
            quantity += (cc3.getText() +" Large Coca Cola ");
        }

        if(Integer.parseInt(md1.getText()) != 0)
        {
            quantity += (md1.getText() +" Small Mountain Dew ");
        }

        if(Integer.parseInt(md2.getText()) != 0)
        {
            quantity += (md2.getText() +" Medium Mountain Dew ");
        }

        if(Integer.parseInt(md3.getText()) != 0)
        {
            quantity += (md3.getText() +" Large Mountain Dew ");
        }

        if(Integer.parseInt(fo1.getText()) != 0)
        {
            quantity += (fo1.getText() +" Small Fanta Orange ");
        }

        if(Integer.parseInt(fo2.getText()) != 0)
        {
            quantity += (fo2.getText() +" Medium Fanta Orange ");
        }

        if(Integer.parseInt(fo3.getText()) != 0)
        {
            quantity += (fo3.getText() +" Large Fanta Orange ");
        }

        if(Integer.parseInt(dr1.getText()) != 0)
        {
            quantity += (dr1.getText() +" Small Dr Pepper ");
        }

        if(Integer.parseInt(dr2.getText()) != 0)
        {
            quantity += (dr2.getText() +" Medium Dr Pepper ");
        }

        if(Integer.parseInt(dr3.getText()) != 0)
        {
            quantity += (dr3.getText() +" Large Dr Pepper ");
        }

        if(Integer.parseInt(sp1.getText()) != 0)
        {
            quantity += (sp1.getText() +" Small Sprite ");
        }

        if(Integer.parseInt(sp2.getText()) != 0)
        {
            quantity += (sp2.getText() +" Medium Sprite ");
        }

        if(Integer.parseInt(sp3.getText()) != 0)
        {
            quantity += (sp3.getText() +" Large Sprite ");
        }

        beverageID = generateID();
        db.add(beverageID,customerPhoneNumber,String.valueOf(totalPrice),quantity,"null","null");

        switchToMenuPage(actionEvent);
    }

    public void switchToMenuPage(ActionEvent actionEvent) throws Exception, IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuPage.fxml"));
        Parent root = loader.load();

        MenuPageController controller = loader.getController();
        controller.setUserNameLabel(user);
        controller.setDeliveryorPickup(deliveryorPickup);
        controller.setCustomerPhoneNumber(customerPhoneNumber);
        controller.setFullNameLabel();
        controller.setPizzaID(beverageID);
        controller.setOrderTextArea();

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    private String generateID()
    {
        String alpha_num = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder s = new StringBuilder();
        Random rand = new Random();
        s.append("b");      //Drink order
        while(s.length() < 5)
        {
            int i = (int)(rand.nextFloat() * alpha_num.length());
            s.append(alpha_num.charAt(i));
        }
        String id = s.toString();
        return id;
    }

    public void setUserNameLabel(String s)
    {
        user = s;
        userNameLabel.setText(s);
    }

    public void setCustomerPhoneNumber(String s )
    {
        customerPhoneNumber = s;
    }

    public void setDeliveryorPickup(String s)
    {
        deliveryorPickup = s;
    }

    @FXML
    public void loggingOut(ActionEvent actionEvent)
    {

    }
}