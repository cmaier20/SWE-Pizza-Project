package com.example.pizza_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class ReceiptPageController {

    private static String user;
    private String customerPhoneNumber;
    private String deliveryorPickup;
    private String textAreaText;
    private double subTotal;
    private double tax_rate = 1.04;


    @FXML
    private Label userNameLabel, orderTypeLabel, addressLabel, paymentTypeLabel, nameLabel;
    @FXML
    private TextArea textAreaReceipt;
    @FXML
    private TextField subtotalField,totalField;

    public void loggingOut(ActionEvent actionEvent)
    {
    }

    public void setTextAreaText(String s)
    {
        textAreaText = s;
    }

    public void setCustomerPhoneNumber(String s )
    {
        customerPhoneNumber = s;
    }

    public void setDeliveryorPickup(String s)
    {
        deliveryorPickup = s;
        orderTypeLabel.setText(s);
    }

    public void setUserNameLabel(String s)
    {
        user =s;
        userNameLabel.setText(s);
    }

    public void setAddressLabel() throws Exception {
        CustomerDatabase db = new CustomerDatabase();
        addressLabel.setText(db.getAddress(customerPhoneNumber));
    }

    public void setSubTotal(double s)
    {
        subTotal = s;
        subtotalField.setText(String.valueOf(s));

        totalField.setText(String.valueOf(s * tax_rate));
    }

    public void setTextAreaReceipt(String s)
    {
        textAreaReceipt.setText(s);
    }

    public void setPaymentTypeLabel() throws Exception {
        CustomerDatabase db = new CustomerDatabase();
        paymentTypeLabel.setText(db.getPaymentType(customerPhoneNumber));
    }

    public void setFullNameLabel() throws Exception
    {
        CustomerDatabase db = new CustomerDatabase();

        String first = db.getFirstName(customerPhoneNumber);
        String last = db.getLastName(customerPhoneNumber);

        nameLabel.setText(first+", "+last);
    }

    @FXML
    public void confirmButtonClicked(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("mainPage.fxml"));
        Parent root = loader.load();

        MainPageController controller = loader.getController();
        controller.setUserNameLabel(user);

        FXMLLoader loader_menu = new FXMLLoader(getClass().getResource("MenuPage.fxml"));
        Parent root_menu = loader_menu.load();
        MenuPageController controller_menu = loader_menu.getController();
        controller_menu.resetText();

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }




}