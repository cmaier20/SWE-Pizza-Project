package com.example.pizza_system;
public class OrderDatabase extends CsvDatabase
{
    public OrderDatabase() throws Exception
    {
        super("OrderDatabase.csv",5,"OrderID,CustomerPhoneNumber,PizzaIDs,Date,PaymentType \r\n");
    }


    public void add(String OrderID, String CustomerPhoneNumber, String PizzaIDs, String Date, String PaymentType) throws Exception
    {
        if(CustomerPhoneNumber.contains(",") || Date.contains(",") || PaymentType.contains(","))
        {
            throw new Exception("Values cannot contain ','");
        }
        open();
        ThisDatabase += OrderID+","+CustomerPhoneNumber+","+PizzaIDs+","+Date+","+PaymentType+"\r";
        close();
    }

    //Getter Methods
    public String getCustomerNumber(String GivenOrderID) throws Exception
    {
        if(indexOf(GivenOrderID) < 0)
        {
            throw new Exception("OrderID not found");
        }
        else
        {
            return fieldAt(indexOf(GivenOrderID) + 1);  //returns customer number of given order id
        }
    }

    public String[] getPizzaIDs(String GivenOrderID) throws Exception
    {
        if(indexOf(GivenOrderID) < 0)
        {
            throw new Exception("OrderID not found");
        }
        else
        {
            String p = fieldAt(indexOf(GivenOrderID) + 2);      //Holds the string of pizza ids
            String [] PizzaIDs = p.split(" ");                  //Splits pizza ids into tokens by spaces
            return PizzaIDs;
        }
    }

    public String getDate(String GivenOrderID) throws Exception
    {
        if(indexOf(GivenOrderID) < 0)
        {
            throw new Exception("OrderID not found");
        }
        else
        {
            return fieldAt(indexOf(GivenOrderID + 3));
        }
    }

    public String getPaymentType(String GivenOrderID) throws Exception
    {
        if(indexOf(GivenOrderID) < 0)
        {
            throw new Exception("OrderID not found");
        }
        else
        {
            return fieldAt(indexOf(GivenOrderID + 4));
        }
    }

    //Setter Methods
    public void setCustomerPhoneNumber(String GivenOrderID, String phoneNumber) throws Exception
    {
        if(indexOf(GivenOrderID) < 0)
        {
            throw new Exception("OrderID was not found");
        }

        else{
            setIndex(indexOf(GivenOrderID) + 1, phoneNumber);
        }
    }

    public void setPizzaIDs(String GivenOrderID, String pizzaIds) throws Exception
    {
        if(indexOf(GivenOrderID) < 0)
        {
            throw new Exception("OrderID was not found");
        }

        else{
            setIndex(indexOf(GivenOrderID) + 2, pizzaIds);
        }
    }

    public void setDate(String GivenOrderID, String Date) throws Exception
    {
        if(indexOf(GivenOrderID) < 0)
        {
            throw new Exception("OrderID was not found");
        }

        else{
            setIndex(indexOf(GivenOrderID) + 3, Date);
        }
    }

    public void setPaymentType(String GivenOrderID, String paymentType) throws Exception
    {
        if(indexOf(GivenOrderID) < 0)
        {
            throw new Exception("OrderID was not found");
        }

        else{
            setIndex(indexOf(GivenOrderID) + 4,paymentType );
        }
    }



}
