package com.example.pizza_system;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class OrdersMainController {

    private static String user;
    private String customerPhoneNumber;
    @FXML
    private TextField phoneNumberField,firstNameField, lastNameField, addressField, paymentTypeField;

    @FXML
    private Label userNameLabel;

    private String deliveryOrPickUp;

    public void findCustomer() throws Exception
    {
        CustomerDatabase database = new CustomerDatabase();

        customerPhoneNumber = phoneNumberField.getText();
        String first = firstNameField.getText();
        String last = lastNameField.getText();
        String address = addressField.getText();
        String paymentType = paymentTypeField.getText();

        if(database.indexOf(customerPhoneNumber) == -1)   //if customer doesn't exist, adds them to database
        {
            database.add(customerPhoneNumber,first,last,paymentType,address);
        }
    }

    @FXML
    public void deliveryButtonClicked(ActionEvent actionEvent) throws Exception {

        findCustomer();
        deliveryOrPickUp = "Delivery";

        FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuPage.fxml"));
        Parent root = loader.load();

        MenuPageController controller = loader.getController();
        controller.setUserNameLabel(user);
        controller.setDeliveryorPickup(deliveryOrPickUp);
        controller.setCustomerPhoneNumber(customerPhoneNumber);
        controller.setFullNameLabel();

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void pickUpButtonClicked(ActionEvent actionEvent) throws Exception
    {
        findCustomer();
        deliveryOrPickUp = "Pick Up";

        FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuPage.fxml"));
        Parent root = loader.load();

        MenuPageController controller = loader.getController();
        controller.setUserNameLabel(user);
        controller.setDeliveryorPickup(deliveryOrPickUp);
        controller.setCustomerPhoneNumber(customerPhoneNumber);
        controller.setFullNameLabel();

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void loggingOut(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(this.getClass().getResource("logOut.fxml"));
            Parent root = (Parent)loader.load();
            LogOutController logOutController = (LogOutController)loader.getController();
            logOutController.setFileString("ordersMainPage.fxml");
            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 650.0D, 500.0D);
            stage.setScene(scene);
            stage.show();
        } catch (IOException var7) {
            System.out.println(var7.getMessage());
        }

    }

    @FXML
    public void goBack(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("mainPage.fxml"));
        Parent root = loader.load();

        MainPageController controller = loader.getController();
        controller.setUserNameLabel(user);

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    public void setUserNameLabel(String s)
    {
        user = s;
        userNameLabel.setText(s);
    }
}