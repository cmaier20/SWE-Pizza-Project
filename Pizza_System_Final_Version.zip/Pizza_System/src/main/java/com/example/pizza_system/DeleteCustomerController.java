package com.example.pizza_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class DeleteCustomerController
{
    private String custPhoneNumber;
    private static String user;

    @FXML
    private Label userNameLabel;

    @FXML
    private TextField firstNameField, lastNameField, phoneNumberField, addressField, paymentType;

    @FXML
    public void yesButtonClicked(ActionEvent actionEvent)
    {
        try
        {
            CustomerDatabase database = new CustomerDatabase(); //opens customer database
            database.remove(custPhoneNumber);

            FXMLLoader loader = new FXMLLoader(getClass().getResource("viewCustomersPage.fxml"));
            Parent root = loader.load();

            ViewCustomersController controller = loader.getController();
            controller.getCustomerData();
            controller.setUserNameLabel(user);

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void noButtonClicked(ActionEvent actionEvent) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("viewCustomersPage.fxml"));
        Parent root = loader.load();

        ViewCustomersController controller = loader.getController();
        controller.getCustomerData();
        controller.setUserNameLabel(user);

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    public void setUserNameLabel(String s)
    {
        user = s;
        userNameLabel.setText(s);
    }

    public void setCustPhoneNumber(String s)
    {
        custPhoneNumber = s;
    }

    public void setTextFields()
    {
        try
        {
            CustomerDatabase database = new CustomerDatabase();
            firstNameField.setText(database.getFirstName(custPhoneNumber));
            lastNameField.setText(database.getLastName(custPhoneNumber));
            phoneNumberField.setText(custPhoneNumber);
            addressField.setText(database.getAddress(custPhoneNumber));
            paymentType.setText(database.getPaymentType(custPhoneNumber));
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
}
