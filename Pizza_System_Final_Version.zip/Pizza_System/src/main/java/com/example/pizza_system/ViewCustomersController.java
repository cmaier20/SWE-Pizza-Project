package com.example.pizza_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class ViewCustomersController
{
    @FXML
    private TextArea textArea;
    @FXML
    private TextField customerPhoneField;
    @FXML
    private Label viewCustomersMessage, userNameLabel;


    public static String user;

    public void getCustomerData() {
        try
        {
            CustomerDatabase customerDatabase = new CustomerDatabase();
            textArea.setText(customerDatabase.toString());    //Gets the contents of customer database. Still in CSV format
        }
        catch(Exception e)
        {
            System.out.println("Error has occurred");
        }
    }

    @FXML
    public void deleteButtonClicked(ActionEvent actionEvent)
    {
        try
        {
            checkManagerAccess(); // Checks if user has managerial access
            isEmptyField(); //Checks if field is empty

            CustomerDatabase database = new CustomerDatabase(); //Opens customer database
            String customerPhoneNumber = customerPhoneField.getText(); //Gets customer phone number input from user
            String dummyVariable = database.getFirstName(customerPhoneNumber); //This just tests if the phone number was in the database, if not throws an error
            switchToDeletePage(actionEvent);    //Switches to the delete screen

        }
        catch(EmptyFieldException e)
        {
            viewCustomersMessage.setText(e.getMessage());
        }
        catch(ManagerAccessError e)
        {
            viewCustomersMessage.setText(e.getMessage());
        }
        catch(IOException e)
        {
            System.out.println("An Unknown Error has occurred");
        }
        catch(Exception e)
        {
            viewCustomersMessage.setText("Customer is not in database");
        }
    }

    @FXML
    public void modifyButtonClicked(ActionEvent actionEvent)
    {
        try
        {
            checkManagerAccess(); // Checks if user has managerial access
            isEmptyField(); //Checks if field is empty

            CustomerDatabase database = new CustomerDatabase(); //Opens customer database
            String customerPhoneNumber = customerPhoneField.getText(); //Gets customer phone number input from user
            String dummyVariable = database.getFirstName(customerPhoneNumber); //This just tests if the phone number was in the database, if not throws an error
            switchToModifyPage(actionEvent);    //Switches to the delete screen

        }
        catch(EmptyFieldException e)
        {
            viewCustomersMessage.setText(e.getMessage());
        }
        catch(ManagerAccessError e)
        {
            viewCustomersMessage.setText(e.getMessage());
        }
        catch(IOException e)
        {
            System.out.println("An Unknown Error has occurred");
        }
        catch(Exception e)
        {
            viewCustomersMessage.setText("Customer is not in database");
        }
    }

    @FXML
    public void loggingOut(ActionEvent actionEvent)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("logOut.fxml"));
            Parent root = loader.load();

            LogOutController logOutController = loader.getController();
            logOutController.setFileString("viewCustomersPage.fxml");
            logOutController.setUserName(user);

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
        }
        catch(IOException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void goBack(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("customersMain.fxml"));
        Parent root = loader.load();

        CustomersMainController controller = loader.getController();
        controller.setUserNameLabel(user);

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToDeletePage(ActionEvent actionEvent) throws IOException  //Switches to screen to make sure user wants to delete the customer
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("deleteCustomerPage.fxml"));
        Parent root = loader.load();

        DeleteCustomerController controller = loader.getController();
        controller.setUserNameLabel(user);
        controller.setCustPhoneNumber(customerPhoneField.getText());
        controller.setTextFields();

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToModifyPage(ActionEvent actionEvent) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("modifyCustomerPage.fxml"));
        Parent root = loader.load();

        ModifyCustomerController controller = loader.getController();
        controller.setUserNameLabel(user);
        controller.setCustPhoneNumber(customerPhoneField.getText());
        controller.setTextFields();

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    public void isEmptyField() throws EmptyFieldException
    {
        //If any of the fields are empty, it will throw an exception
        if(customerPhoneField.getText().isEmpty())
        {
            throw new EmptyFieldException("All fields must be filled out!");
        }

    }

    public void checkManagerAccess() throws ManagerAccessError,Exception
    {
        EmployeeDatabase e = new EmployeeDatabase();

        if(!e.checkManagerialAccess(user))
        {
            throw new ManagerAccessError("You don't have Managerial Access!");
        }
    }

    public void setUserNameLabel(String s)
    {
        user = s;
        userNameLabel.setText(user);
    }
}
