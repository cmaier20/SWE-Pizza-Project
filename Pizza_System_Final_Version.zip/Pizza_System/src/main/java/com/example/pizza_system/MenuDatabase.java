package com.example.pizza_system;
public class MenuDatabase extends CsvDatabase{
    //Constructor Method
    MenuDatabase() throws Exception{
        super("MenuDatabase.csv", 3, "Name,Type,Price\r\n");
    }

    //Setter Methods

    //Adds a Item to the Menu
    public void add(String Name, String Type, float price) throws Exception{
        //if the passed information has too many commas through an Exception
        if(Name.contains(",") || Type.contains(",")) {
            throw new Exception("Username and Password can not contain any ','");
        }
        open();
        ThisDatabase += Name+","+Type+","+price+"\r";
        close();
    }

    //Sets the type using the GivenName
    public void setType(String NewType, String GivenName) {
        setIndex(indexOf(GivenName)+1, NewType);
    }

    //Sets the price using the GivenName
    public void setPrice(String NewPrice, String GivenName) {
        setIndex(indexOf(GivenName)+2, NewPrice);
    }


    //Getter Methods

    //Gets the type using the GivenName
    public String getType(String GivenName) {
        if(indexOf(GivenName) != -1) {
            return fieldAt(indexOf(GivenName)+1);
        }
        else
            return null;
    }

    //Gets the price using the GivenName
    public String getPrice(String GivenName) {
        if(indexOf(GivenName) != -1) {
            return fieldAt(indexOf(GivenName)+2);
        }
        else
            return null;
    }

    //Returns true if the database contains GivenName, else false
    public boolean stock(String GivenName) {
        if(indexOf(GivenName) != -1) {
            return true;
        }
        else
            return false;
    }
}
