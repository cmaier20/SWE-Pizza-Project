package com.example.pizza_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.io.IOException;

public class MainPageController
{
    @FXML
    private Label usernameLabel;
    private static String user;

    @FXML
    public void ordersButtonClicked(ActionEvent actionEvent) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ordersMainPage.fxml"));
        Parent root = loader.load();

        OrdersMainController controller = loader.getController();
        controller.setUserNameLabel(user);

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    public void customersButtonClicked(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("customersMain.fxml"));
        Parent root = loader.load();

        CustomersMainController controller = loader.getController();
        controller.setUserNameLabel(user);

        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root,650,500);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void loggingOut(ActionEvent actionEvent) //Calls the logOut fxml window
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("logOut.fxml"));
            Parent root = loader.load();

            LogOutController logOutController = loader.getController();
            logOutController.setFileString("mainPage.fxml");
            logOutController.setUserName(user);

            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root,650,500);
            stage.setScene(scene);
            stage.show();
        }
        catch(IOException e)
        {
            System.out.println(e.getMessage());
        }
    }

    public void setUserNameLabel(String userName)   //Set the username in upper right corner to username
    {
        user = userName;
        usernameLabel.setText(userName);
    }








}