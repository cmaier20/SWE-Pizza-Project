module com.example.pizza_system {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.pizza_system to javafx.fxml;
    exports com.example.pizza_system;
}